package com.jwt.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.jwt.example.model.User;

@Service
public class UserService {
	
	private List<User> userDetails = new ArrayList<>();
	
	public UserService() {
		userDetails.add(new User(UUID.randomUUID().toString(), "Raj", "Raj997323@gmail.com"));
		userDetails.add(new User(UUID.randomUUID().toString(), "Rahul", "Rahul997323@gmail.com"));
		userDetails.add(new User(UUID.randomUUID().toString(), "Sonu", "sonu52153@gmail.com"));
		userDetails.add(new User(UUID.randomUUID().toString(), "Priyanka", "priyanka52153@gmail.com"));
	}

	public List<User> getUsers(){
		return userDetails;
	}
}
